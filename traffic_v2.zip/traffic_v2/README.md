# TrafficIQ India v2 — Complete Traffic Intelligence Platform

## What's new in v2
- ✅ All sidebar pages fully working: Dashboard, Hourly Trends, Vehicle Types, City Map, Route Checker
- ✅ Date filter — pick any past date to view historical data
- ✅ 7 vehicle types with emoji icons (including E-Vehicles!)
- ✅ AQI / Pollution monitoring metric
- ✅ Hourly stacked bar chart by vehicle type
- ✅ 7-day vehicle trend chart
- ✅ Morning vs Evening peak comparison
- ✅ India city heatmap with clickable city dots
- ✅ Smart Route Checker with 2 route options + congestion score + suggestion
- ✅ Popular routes per city (pre-filled quick select)
- ✅ Vibrant gradient dark theme throughout

## Setup
```bash
pip install flask
python app.py
```
Then open: http://127.0.0.1:5000

## Pages
| Page | What it shows |
|------|--------------|
| Dashboard | Metrics, hourly chart, donut, vehicle bars |
| Hourly Trends | 24hr line, stacked bar by type, peak compare |
| Vehicle Types | Cards per vehicle + 7-day weekly trend |
| City Map | India map with city dots, city traffic list |
| Route Checker | Origin → Destination, 2 routes, suggestion |

## Project structure
```
traffic_v2/
├── app.py
├── requirements.txt
├── data/users.json      ← auto-created
├── templates/
│   ├── login.html
│   ├── signup.html
│   └── dashboard.html
└── static/
    ├── css/auth.css
    ├── css/dashboard.css
    └── js/dashboard.js
```
