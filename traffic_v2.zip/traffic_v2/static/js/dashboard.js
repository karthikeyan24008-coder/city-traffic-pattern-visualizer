/* TrafficIQ Dashboard JS */
const COLORS = ["#6C63FF","#F7971E","#12c2e9","#f64f59","#43e97b","#a18cd1","#00d2ff"];
const ICONS  = ["🏍️","🚗","🛺","🚌","🚛","🚲","⚡"];
let charts = {};
let lastData = null;

function city(){ return document.getElementById("city-select").value; }
function hour(){ return document.getElementById("hour-select").value; }
function date(){ return document.getElementById("date-select").value; }
function fmtHour(h){ if(h===0)return"12 AM"; if(h<12)return h+" AM"; if(h===12)return"12 PM"; return(h-12)+" PM"; }
function fmtNum(n){ return n>=1000?(n/1000).toFixed(1)+"k":n.toString(); }

/* ── Page navigation ── */
const PAGE_TITLES = {dashboard:"Traffic Dashboard",hourly:"Hourly Trends",vtypes:"Vehicle Types",citymap:"City Map",route:"Route Checker"};
function showPage(name, btn){
  document.querySelectorAll(".tab-page").forEach(p=>p.classList.remove("active"));
  document.querySelectorAll(".sb-link").forEach(b=>b.classList.remove("active"));
  document.getElementById("page-"+name).classList.add("active");
  document.getElementById("page-title").textContent = PAGE_TITLES[name];
  if(btn) btn.classList.add("active");
  if(name==="hourly") loadHourly();
  if(name==="vtypes") loadVtypes();
  if(name==="citymap") loadCityMap();
  if(name==="route") loadPopularRoutes();
}

/* ── Destroy chart helper ── */
function destroyChart(key){
  if(charts[key]){ charts[key].destroy(); delete charts[key]; }
}

/* ── Chart defaults ── */
const gridColor = "rgba(255,255,255,0.05)";
const tickColor = "rgba(255,255,255,0.3)";
const tooltipBg = "rgba(10,8,28,0.92)";
const baseChartOpts = {
  responsive:true, maintainAspectRatio:false,
  plugins:{ legend:{ display:false }, tooltip:{ backgroundColor:tooltipBg, borderColor:"rgba(108,99,255,0.35)", borderWidth:1, titleColor:"rgba(255,255,255,0.9)", bodyColor:"rgba(255,255,255,0.6)" }},
  scales:{ x:{ ticks:{color:tickColor,font:{size:11}}, grid:{color:gridColor} }, y:{ ticks:{color:tickColor,font:{size:11}, callback:v=>fmtNum(v)}, grid:{color:gridColor} }}
};

/* ══ DASHBOARD ══ */
async function loadDashboard(){
  const res = await fetch(`/api/traffic?city=${encodeURIComponent(city())}&hour=${hour()}&date=${date()}`);
  const d = await res.json();
  lastData = d;
  renderMetrics(d);
  renderHourlyChart(d);
  renderDonutChart(d);
  renderVBars(d);
  renderCityStrip(d);
}

function renderMetrics(d){
  document.getElementById("m-total").textContent = d.total.toLocaleString();
  document.getElementById("m-cong").textContent = d.congestion;
  document.getElementById("m-cong-sub").textContent = d.congestion==="High"?"🔴 Heavy traffic":d.congestion==="Moderate"?"🟡 Moderate flow":"🟢 Moving well";
  document.getElementById("m-speed").textContent = d.avg_speed+" km/h";
  document.getElementById("m-peak").textContent = fmtHour(d.peak_hour);
  const aqi = d.pollution_aqi;
  const aqiLabel = aqi<50?"Good 🟢":aqi<100?"Satisfactory 🟡":aqi<200?"Moderate 🟠":aqi<300?"Poor 🔴":"Severe 🟣";
  document.getElementById("m-aqi").textContent = aqi;
  document.getElementById("m-aqi-label").textContent = aqiLabel;
  const topIdx = d.vehicle_counts.indexOf(Math.max(...d.vehicle_counts));
  document.getElementById("m-top").textContent = ICONS[topIdx]+" "+d.vehicle_types[topIdx].split("/")[0];
  document.getElementById("city-badge").textContent = d.city+", "+d.state;
}

function renderHourlyChart(d){
  destroyChart("hourly");
  const ctx = document.getElementById("hourly-chart").getContext("2d");
  const grad = ctx.createLinearGradient(0,0,0,200);
  grad.addColorStop(0,"rgba(108,99,255,0.55)");
  grad.addColorStop(1,"rgba(108,99,255,0.02)");
  const selectedH = parseInt(hour());
  charts.hourly = new Chart(ctx,{
    type:"line",
    data:{ labels: Array.from({length:24},(_,i)=>fmtHour(i)),
      datasets:[{ data:d.hourly_series, borderColor:"#6C63FF", backgroundColor:grad,
        borderWidth:2.5, fill:true, tension:0.4,
        pointRadius:d.hourly_series.map((_,i)=>i===selectedH?7:0),
        pointBackgroundColor:"#f64f59", pointBorderColor:"#fff", pointBorderWidth:2 }]},
    options:{...baseChartOpts, plugins:{...baseChartOpts.plugins,
      tooltip:{...baseChartOpts.plugins.tooltip, callbacks:{label:c=>"  Vehicles: "+c.raw.toLocaleString()}}}}
  });
}

function renderDonutChart(d){
  destroyChart("donut");
  const ctx = document.getElementById("type-chart").getContext("2d");
  charts.donut = new Chart(ctx,{
    type:"doughnut",
    data:{ labels:d.vehicle_types,
      datasets:[{ data:d.vehicle_counts, backgroundColor:COLORS,
        borderColor:"rgba(8,7,26,0.8)", borderWidth:3, hoverOffset:8 }]},
    options:{ responsive:true, maintainAspectRatio:false, cutout:"62%",
      plugins:{ legend:{ position:"bottom", labels:{color:"rgba(255,255,255,0.55)",font:{size:10},padding:8,boxWidth:10,boxHeight:10}},
        tooltip:{backgroundColor:tooltipBg, callbacks:{label:c=>"  "+c.raw.toLocaleString()+" vehicles"}}}}
  });
}

function renderVBars(d){
  const max = Math.max(...d.vehicle_counts);
  document.getElementById("vbars").innerHTML = d.vehicle_types.map((name,i)=>{
    const pct = Math.round(d.vehicle_counts[i]/max*100);
    return `<div class="vrow">
      <span class="vicon">${ICONS[i]}</span>
      <span class="vname">${name}</span>
      <div class="vtrack"><div class="vfill" style="width:${pct}%;background:${COLORS[i]}"></div></div>
      <span class="vcount">${d.vehicle_counts[i].toLocaleString()}</span>
    </div>`;
  }).join("");
}

function renderCityStrip(d){
  const morePct = Math.round(d.vehicle_counts[0]/d.total*100);
  const carPct  = Math.round(d.vehicle_counts[1]/d.total*100);
  document.getElementById("city-strip").innerHTML = [
    [d.city,"City"],[d.state,"State"],[fmtHour(parseInt(hour())),"Selected Hour"],
    [d.congestion+" Traffic","Status"],[d.avg_speed+" km/h","Avg Speed"],
    [morePct+"%","Two-wheelers share"],[carPct+"%","Cars/SUVs share"],[d.pollution_aqi,"AQI"],
  ].map(([v,l])=>`<div class="ci-item"><span class="ci-label">${l}</span><span class="ci-val">${v}</span></div>`).join("");
}

/* ══ HOURLY TRENDS ══ */
async function loadHourly(){
  const res = await fetch(`/api/hourly_trends?city=${encodeURIComponent(city())}&date=${date()}`);
  const d = await res.json();
  document.getElementById("trends-badge").textContent = city()+" · "+date();
  renderTotalTrend(d);
  renderStackedTrend(d);
  renderPeakCompare(d);
}

function renderTotalTrend(d){
  destroyChart("trendTotal");
  const ctx = document.getElementById("trends-total-chart").getContext("2d");
  const grad = ctx.createLinearGradient(0,0,0,260);
  grad.addColorStop(0,"rgba(18,194,233,0.5)");
  grad.addColorStop(1,"rgba(18,194,233,0.02)");
  charts.trendTotal = new Chart(ctx,{
    type:"line",
    data:{ labels:d.labels, datasets:[{ data:d.total_series, borderColor:"#12c2e9",
      backgroundColor:grad, borderWidth:2.5, fill:true, tension:0.4,
      pointRadius:4, pointBackgroundColor:"#12c2e9", pointBorderColor:"#fff", pointBorderWidth:1.5 }]},
    options:{...baseChartOpts, plugins:{...baseChartOpts.plugins,
      tooltip:{...baseChartOpts.plugins.tooltip, callbacks:{label:c=>"  Total: "+c.raw.toLocaleString()}}}}
  });
}

function renderStackedTrend(d){
  destroyChart("trendStacked");
  const ctx = document.getElementById("trends-stacked-chart").getContext("2d");
  const vtypes = Object.keys(d.vehicle_series);
  charts.trendStacked = new Chart(ctx,{
    type:"bar",
    data:{ labels:d.labels,
      datasets: vtypes.map((vt,i)=>({
        label:vt, data:d.vehicle_series[vt],
        backgroundColor:COLORS[i]+"cc", borderColor:COLORS[i],
        borderWidth:0, borderRadius:2, stack:"s"
      }))
    },
    options:{...baseChartOpts,
      plugins:{ legend:{ display:true, position:"bottom", labels:{color:"rgba(255,255,255,0.55)",font:{size:10},padding:8,boxWidth:10,boxHeight:10}},
        tooltip:{backgroundColor:tooltipBg, mode:"index", intersect:false}},
      scales:{ x:{ticks:{color:tickColor,font:{size:10}},grid:{color:gridColor},stacked:true},
        y:{ticks:{color:tickColor,font:{size:10},callback:v=>fmtNum(v)},grid:{color:gridColor},stacked:true}}}
  });
}

function renderPeakCompare(d){
  const amData = Object.keys(d.vehicle_series).map(vt=>d.vehicle_series[vt][8]);
  const pmData = Object.keys(d.vehicle_series).map(vt=>d.vehicle_series[vt][18]);
  const vtypes = Object.keys(d.vehicle_series);
  const maxVal = Math.max(...amData,...pmData);
  document.getElementById("peak-compare").innerHTML = vtypes.map((vt,i)=>{
    const amPct = Math.round(amData[i]/maxVal*100);
    const pmPct = Math.round(pmData[i]/maxVal*100);
    return `<div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
      <span style="font-size:18px">${ICONS[i]}</span>
      <span style="font-size:12px;color:rgba(255,255,255,.5);width:110px">${vt}</span>
      <div style="flex:1">
        <div style="display:flex;gap:4px;align-items:center;margin-bottom:4px">
          <span style="font-size:10px;color:#F7971E;width:28px">8AM</span>
          <div style="flex:1;height:7px;background:rgba(255,255,255,.07);border-radius:4px"><div style="width:${amPct}%;height:100%;border-radius:4px;background:#F7971E"></div></div>
          <span style="font-size:11px;font-weight:700;color:#fff;width:48px;text-align:right">${amData[i].toLocaleString()}</span>
        </div>
        <div style="display:flex;gap:4px;align-items:center">
          <span style="font-size:10px;color:#6C63FF;width:28px">6PM</span>
          <div style="flex:1;height:7px;background:rgba(255,255,255,.07);border-radius:4px"><div style="width:${pmPct}%;height:100%;border-radius:4px;background:#6C63FF"></div></div>
          <span style="font-size:11px;font-weight:700;color:#fff;width:48px;text-align:right">${pmData[i].toLocaleString()}</span>
        </div>
      </div>
    </div>`;
  }).join("");
}

/* ══ VEHICLE TYPES ══ */
async function loadVtypes(){
  const res = await fetch(`/api/vehicle_types?city=${encodeURIComponent(city())}&date=${date()}`);
  const d = await res.json();
  const traffic = lastData || {total:1,vehicle_counts:Array(7).fill(0)};
  const total   = traffic.vehicle_counts.reduce((a,b)=>a+b,0)||1;
  document.getElementById("vtypes-grid").innerHTML = d.trend && Object.keys(d.trend).map((vt,i)=>{
    const cnt = traffic.vehicle_counts[i]||0;
    const pct = Math.round(cnt/total*100);
    const weekly_max = Math.max(...d.trend[vt]);
    return `<div class="vtype-card" style="border-color:${COLORS[i]}33">
      <span class="vtype-emoji">${ICONS[i]}</span>
      <div class="vtype-name">${vt}</div>
      <div class="vtype-count-big" style="color:${COLORS[i]}">${cnt.toLocaleString()}</div>
      <div class="vtype-pct">${pct}% of total traffic</div>
      <div class="vtype-bar-mini"><div class="vtype-bar-fill" style="width:${pct}%;background:${COLORS[i]}"></div></div>
    </div>`;
  }).join("");
  renderWeekChart(d);
}

function renderWeekChart(d){
  destroyChart("week");
  const ctx = document.getElementById("week-chart").getContext("2d");
  charts.week = new Chart(ctx,{
    type:"line",
    data:{ labels:d.dates,
      datasets: Object.keys(d.trend).map((vt,i)=>({
        label:vt, data:d.trend[vt],
        borderColor:COLORS[i], backgroundColor:"transparent",
        borderWidth:2, pointRadius:4, pointBackgroundColor:COLORS[i],
        pointBorderColor:"#fff", pointBorderWidth:1.5, tension:0.35
      }))
    },
    options:{...baseChartOpts,
      plugins:{ legend:{display:true,position:"bottom",labels:{color:"rgba(255,255,255,.55)",font:{size:10},padding:8,boxWidth:10,boxHeight:10}},
        tooltip:{backgroundColor:tooltipBg,mode:"index",intersect:false}}}
  });
}

/* ══ CITY MAP ══ */
const CITY_COORDS = {
  Mumbai:[195,290],Delhi:[175,115],Bangalore:[175,375],Chennai:[190,360],
  Hyderabad:[180,325],Kolkata:[250,230],Pune:[160,310],Ahmedabad:[130,230],
  Jaipur:[155,175],Surat:[135,265],Lucknow:[200,170],Kochi:[165,405],
  Indore:[155,245],Salem:[180,385],Coimbatore:[165,390]
};

async function loadCityMap(){
  const res  = await fetch("/api/city_map");
  const d    = await res.json();
  const dots = document.getElementById("map-dots");
  dots.innerHTML = "";
  d.cities.forEach(c=>{
    const [x,y] = CITY_COORDS[c.name]||[200,250];
    const r = c.name===city()?9:6;
    const g = document.createElementNS("http://www.w3.org/2000/svg","g");
    g.style.cursor="pointer";
    g.onclick=()=>{ document.getElementById("city-select").value=c.name; refreshAll(); };
    g.innerHTML=`
      <circle cx="${x}" cy="${y}" r="${r+5}" fill="${c.color}" opacity="0.2"/>
      <circle cx="${x}" cy="${y}" r="${r}" fill="${c.color}" stroke="white" stroke-width="${c.name===city()?2:1}"/>
      <text x="${x}" y="${y+15}" text-anchor="middle" class="map-label" style="font-size:8px;fill:rgba(255,255,255,0.7)">${c.name}</text>`;
    dots.appendChild(g);
  });
  const panel = document.getElementById("map-cities-panel");
  const sorted = [...d.cities].sort((a,b)=>b.total-a.total);
  panel.innerHTML = sorted.map(c=>`
    <div class="city-row" onclick="document.getElementById('city-select').value='${c.name}';refreshAll()">
      <div style="display:flex;justify-content:space-between;align-items:flex-start">
        <div><div class="city-row-name">${c.name}</div><div class="city-row-state">${c.state}</div></div>
        <div class="city-row-right">
          <span class="city-status status-${c.status.toLowerCase()}">${c.status}</span>
          <div class="city-row-count">${c.total.toLocaleString()} vehicles/hr</div>
        </div>
      </div>
    </div>`).join("");
}

/* ══ ROUTE CHECKER ══ */
const POPULAR = {
  Mumbai:[["Andheri","Bandra"],["Dadar","Churchgate"]],
  Delhi:[["Noida","Connaught Place"],["Gurgaon","IGI Airport"]],
  Bangalore:[["Whitefield","MG Road"],["Electronic City","Silk Board"]],
  Chennai:[["Tambaram","Anna Nagar"],["OMR","T.Nagar"]],
  Hyderabad:[["Hitech City","Secunderabad"],["Gachibowli","Charminar"]],
  Kolkata:[["Salt Lake","Howrah"],["Dum Dum","Park Street"]],
  Pune:[["Hinjewadi","Koregaon Park"],["Wakad","Hadapsar"]],
  Ahmedabad:[["Satellite","Maninagar"],["Bopal","ISCON"]],
  Jaipur:[["Mansarovar","MI Road"],["Vaishali Nagar","Sindhi Camp"]],
  Salem:[["Fairlands","Shevapet"],["Suramangalam","Junction"]],
  default:[["North Zone","City Center"],["South Zone","Station"]]
};

function loadPopularRoutes(){
  const c = document.getElementById("route-city").value;
  const routes = POPULAR[c]||POPULAR.default;
  document.getElementById("popular-routes").innerHTML = routes.map(([o,d])=>`
    <button style="padding:6px 12px;border-radius:20px;background:rgba(108,99,255,0.15);border:1px solid rgba(108,99,255,0.3);color:rgba(255,255,255,0.8);font-size:12px;cursor:pointer;font-family:'Inter',sans-serif"
      onclick="document.getElementById('route-origin').value='${o}';document.getElementById('route-dest').value='${d}'">
      📍 ${o} → ${d}
    </button>`).join("");
}

document.getElementById("route-city").addEventListener("change", loadPopularRoutes);

async function checkRoute(){
  const origin = document.getElementById("route-origin").value.trim();
  const dest   = document.getElementById("route-dest").value.trim();
  const rcity  = document.getElementById("route-city").value;
  if(!origin||!dest){ alert("Please enter both origin and destination."); return; }
  const btn = document.getElementById("check-btn");
  btn.disabled=true;
  btn.innerHTML='<span class="loading-spinner"></span>Checking routes…';
  const res = await fetch("/api/route_check",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({city:rcity,origin,destination:dest})});
  const d = await res.json();
  btn.disabled=false; btn.innerHTML="Check Best Route →";
  renderRouteResult(d);
}

function renderRouteResult(d){
  const mr = d.main_route, ar = d.alt_route;
  const statusClass = s => s==="Heavy"?"status-high":s==="Moderate"?"status-mod":"status-low";
  document.getElementById("route-result-card").innerHTML = `
    <div class="route-result">
      <div class="route-header">
        <div class="route-od">📍 ${d.origin}<span>→</span>🏁 ${d.destination}</div>
        <div class="route-city-tag">${d.city} · Current traffic analysis</div>
      </div>
      <div class="route-option" style="border-color:${mr.color}44;background:${mr.color}11">
        <div class="route-option-name">🚀 ${mr.name}</div>
        <div class="route-via">${mr.via}</div>
        <div class="route-stats">
          <div class="rstat"><div class="rstat-val">${mr.time} min</div><div class="rstat-lbl">Est. time</div></div>
          <div class="rstat"><div class="rstat-val">${mr.distance} km</div><div class="rstat-lbl">Distance</div></div>
        </div>
        <span class="route-status-pill city-status ${statusClass(mr.status)}">${mr.status} Traffic</span>
      </div>
      <div class="route-option" style="border-color:${ar.color}44;background:${ar.color}11">
        <div class="route-option-name">🔀 ${ar.name}</div>
        <div class="route-via">${ar.via}</div>
        <div class="route-stats">
          <div class="rstat"><div class="rstat-val">${ar.time} min</div><div class="rstat-lbl">Est. time</div></div>
          <div class="rstat"><div class="rstat-val">${ar.distance} km</div><div class="rstat-lbl">Distance</div></div>
        </div>
        <span class="route-status-pill city-status ${statusClass(ar.status)}">${ar.status} Traffic</span>
      </div>
      <div class="congestion-meter">
        <div class="cong-label">Current congestion score for ${d.city}</div>
        <div class="cong-track"><div class="cong-fill" style="width:${d.congestion_score}%;background:${d.congestion_score>70?'#f64f59':d.congestion_score>40?'#F7971E':'#43e97b'}"></div></div>
        <div class="cong-score" style="color:${d.congestion_score>70?'#f64f59':d.congestion_score>40?'#F7971E':'#43e97b'}">${d.congestion_score}/100</div>
      </div>
      <div class="suggestion-box">
        <span class="sug-icon">💡</span>
        <div class="sug-text">${d.recommendation}</div>
      </div>
    </div>`;
}

/* ══ Global refresh ══ */
function refreshAll(){
  const active = document.querySelector(".tab-page.active");
  if(!active) return;
  const id = active.id.replace("page-","");
  if(id==="dashboard") loadDashboard();
  else if(id==="hourly") loadHourly();
  else if(id==="vtypes") loadVtypes();
  else if(id==="citymap") loadCityMap();
}

document.getElementById("city-select").addEventListener("change", refreshAll);
document.getElementById("hour-select").addEventListener("change", refreshAll);
document.getElementById("date-select").addEventListener("change", refreshAll);

/* ── Init ── */
loadDashboard();
