from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import json, os, hashlib, random
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = "trafficiq_v2_secret_2024"

USERS_FILE = "data/users.json"

def load_users():
    if not os.path.exists(USERS_FILE):
        return {}
    with open(USERS_FILE) as f:
        return json.load(f)

def save_users(u):
    with open(USERS_FILE, "w") as f:
        json.dump(u, f)

def hash_pw(pw):
    return hashlib.sha256(pw.encode()).hexdigest()

CITIES = {
    "Mumbai":    {"mult":1.8,"state":"Maharashtra","lat":19.076,"lng":72.877},
    "Delhi":     {"mult":2.0,"state":"Delhi",       "lat":28.613,"lng":77.209},
    "Bangalore": {"mult":1.7,"state":"Karnataka",   "lat":12.971,"lng":77.594},
    "Chennai":   {"mult":1.5,"state":"Tamil Nadu",  "lat":13.082,"lng":80.270},
    "Hyderabad": {"mult":1.6,"state":"Telangana",   "lat":17.385,"lng":78.486},
    "Kolkata":   {"mult":1.4,"state":"West Bengal", "lat":22.572,"lng":88.363},
    "Pune":      {"mult":1.3,"state":"Maharashtra", "lat":18.520,"lng":73.856},
    "Ahmedabad": {"mult":1.2,"state":"Gujarat",     "lat":23.022,"lng":72.571},
    "Jaipur":    {"mult":1.1,"state":"Rajasthan",   "lat":26.912,"lng":75.787},
    "Surat":     {"mult":1.0,"state":"Gujarat",     "lat":21.170,"lng":72.831},
    "Lucknow":   {"mult":1.0,"state":"Uttar Pradesh","lat":26.846,"lng":80.946},
    "Kochi":     {"mult":0.9,"state":"Kerala",      "lat":9.931, "lng":76.267},
    "Indore":    {"mult":0.9,"state":"Madhya Pradesh","lat":22.719,"lng":75.857},
    "Salem":     {"mult":0.7,"state":"Tamil Nadu",  "lat":11.664,"lng":78.146},
    "Coimbatore":{"mult":0.8,"state":"Tamil Nadu",  "lat":11.017,"lng":76.955},
}

VEHICLE_TYPES  = ["Two-wheelers","Cars/SUVs","Autos/Taxis","Buses","Trucks/Lorries","Cycles","E-Vehicles"]
VEHICLE_COLORS = ["#6C63FF","#F7971E","#12c2e9","#f64f59","#43e97b","#a18cd1","#00d2ff"]
VEHICLE_ICONS  = ["🏍️","🚗","🛺","🚌","🚛","🚲","⚡"]

HOUR_FACTORS = [0.15,0.10,0.08,0.07,0.08,0.20,0.50,0.85,1.00,0.80,
                0.70,0.72,0.78,0.72,0.68,0.75,0.88,1.00,0.90,0.75,
                0.60,0.45,0.32,0.22]

# Famous routes per city
ROUTES = {
    "Mumbai":   [("Andheri","Bandra"),("Dadar","Churchgate"),("Borivali","CST"),("Thane","Worli"),("Kurla","Nariman Point")],
    "Delhi":    [("Noida","Connaught Place"),("Gurgaon","IGI Airport"),("Dwarka","Lajpat Nagar"),("Rohini","AIIMS"),("Vasant Kunj","Karol Bagh")],
    "Bangalore":[("Whitefield","MG Road"),("Electronic City","Koramangala"),("Hebbal","Silk Board"),("Marathahalli","Indiranagar"),("HSR Layout","Airport")],
    "Chennai":  [("Tambaram","Anna Nagar"),("OMR","T.Nagar"),("Porur","Egmore"),("Velachery","Central"),("Adyar","Guindy")],
    "Hyderabad":[("Hitech City","Secunderabad"),("Gachibowli","Charminar"),("Kukatpally","LB Nagar"),("Madhapur","Uppal"),("Ameerpet","Airport")],
    "Kolkata":  [("Salt Lake","Howrah"),("Dum Dum","Park Street"),("Jadavpur","Esplanade"),("Barasat","BBD Bag"),("New Town","Sealdah")],
    "Pune":     [("Hinjewadi","Koregaon Park"),("Wakad","Hadapsar"),("Kothrud","Magarpatta"),("Baner","Pune Station"),("Viman Nagar","Swargate")],
    "Ahmedabad":[("Satellite","Maninagar"),("Bopal","ISCON"),("Navrangpura","Vatva"),("Gandhinagar","CG Road"),("Thaltej","Kalupur")],
    "Jaipur":   [("Mansarovar","MI Road"),("Vaishali Nagar","Sindhi Camp"),("Malviya Nagar","Bani Park"),("Jagatpura","Civil Lines"),("C-Scheme","Airport")],
    "Salem":    [("Fairlands","Shevapet"),("Suramangalam","Junction"),("Kondalampatti","Four Roads"),("Gugai","Salem Junction"),("Attur Road","SRMC")],
    "default":  [("Area A","Area B"),("North Zone","City Center"),("South Zone","Railway Station"),("East Zone","Market"),("West Zone","Hospital")],
}

def hour_factor(h): return HOUR_FACTORS[h % 24]

def get_routes(city):
    return ROUTES.get(city, ROUTES["default"])

def generate_traffic(city, hour, date_str=None):
    seed_base = hash(city + str(hour) + (date_str or ""))
    random.seed(seed_base)
    mult = CITIES[city]["mult"]
    hf   = hour_factor(hour)
    base = 8000
    total = int(base * mult * hf * random.uniform(0.92, 1.08))
    big = mult > 1.4
    splits = [0.38,0.26,0.13,0.09,0.07,0.04,0.03] if big else \
             [0.42,0.20,0.14,0.11,0.05,0.04,0.04]
    counts = [int(total * s * random.uniform(0.9, 1.1)) for s in splits]
    random.seed()
    return total, counts

def generate_hourly_series(city, date_str=None):
    return [generate_traffic(city, h, date_str)[0] for h in range(24)]

def generate_route_suggestion(origin, dest, city):
    mult = CITIES.get(city,{}).get("mult",1.0)
    hf   = hour_factor(datetime.now().hour)
    cong = hf * mult
    main_time   = int(25 + cong * 20 + random.uniform(-3,3))
    alt_time    = int(main_time * random.uniform(0.75, 0.92))
    main_dist   = round(random.uniform(8,22), 1)
    alt_dist    = round(main_dist * random.uniform(1.0, 1.15), 1)
    main_status = "Heavy" if cong > 1.2 else "Moderate" if cong > 0.7 else "Light"
    alt_status  = "Light" if cong > 0.7 else "Very Light"
    via_main = f"via {city} Main Road / NH"
    via_alt  = f"via Inner Ring Road / Bypass"
    return {
        "origin": origin, "destination": dest, "city": city,
        "main_route": {"name": "Fastest (recommended by traffic)", "via": via_main,
                       "time": main_time, "distance": main_dist, "status": main_status,
                       "color": "#f64f59" if main_status=="Heavy" else "#F7971E" if main_status=="Moderate" else "#43e97b"},
        "alt_route":  {"name": "Alternative route", "via": via_alt,
                       "time": alt_time,  "distance": alt_dist,  "status": alt_status,
                       "color": "#43e97b"},
        "recommendation": f"Take the alternative route via bypass — save ~{main_time-alt_time} minutes.",
        "congestion_score": round(min(cong * 50, 100), 1),
    }

# ── Auth routes ──────────────────────────────────────────────────
@app.route("/")
def index():
    return redirect(url_for("dashboard") if "user" in session else url_for("login"))

@app.route("/login", methods=["GET","POST"])
def login():
    error = None
    if request.method == "POST":
        users = load_users()
        u, p  = request.form.get("username","").strip(), request.form.get("password","")
        if u in users and users[u]["password"] == hash_pw(p):
            session["user"] = u
            return redirect(url_for("dashboard"))
        error = "Invalid username or password."
    return render_template("login.html", error=error)

@app.route("/signup", methods=["GET","POST"])
def signup():
    error = None
    if request.method == "POST":
        users = load_users()
        u  = request.form.get("username","").strip()
        em = request.form.get("email","").strip()
        p  = request.form.get("password","")
        p2 = request.form.get("confirm_password","")
        if not u or not em or not p:        error = "All fields are required."
        elif u in users:                    error = "Username already taken."
        elif p != p2:                       error = "Passwords do not match."
        elif len(p) < 6:                    error = "Password must be 6+ characters."
        else:
            users[u] = {"email": em, "password": hash_pw(p)}
            save_users(users); session["user"] = u
            return redirect(url_for("dashboard"))
    return render_template("signup.html", error=error)

@app.route("/logout")
def logout():
    session.pop("user", None); return redirect(url_for("login"))

@app.route("/dashboard")
def dashboard():
    if "user" not in session: return redirect(url_for("login"))
    now = datetime.now()
    return render_template("dashboard.html",
        user=session["user"],
        cities=sorted(CITIES.keys()),
        current_hour=now.hour,
        current_date=now.strftime("%Y-%m-%d"),
        current_time=now.strftime("%I:%M %p"),
        vehicle_types=VEHICLE_TYPES,
        vehicle_colors=VEHICLE_COLORS,
        vehicle_icons=VEHICLE_ICONS,
    )

# ── API routes ───────────────────────────────────────────────────
@app.route("/api/traffic")
def api_traffic():
    city = request.args.get("city","Mumbai")
    hour = int(request.args.get("hour", datetime.now().hour))
    date = request.args.get("date", datetime.now().strftime("%Y-%m-%d"))
    if city not in CITIES: return jsonify({"error":"City not found"}),404
    total, counts = generate_traffic(city, hour, date)
    hourly = generate_hourly_series(city, date)
    peak   = hourly.index(max(hourly))
    hf     = hour_factor(hour)
    congestion = "High" if hf > 0.85 else "Moderate" if hf > 0.6 else "Low"
    avg_speed  = max(10, int(60 * (1 - hf * 0.7)))
    pollution  = int(min(500, 80 + hf * CITIES[city]["mult"] * 120 + random.uniform(-10,10)))
    return jsonify({
        "city":city,"state":CITIES[city]["state"],
        "hour":hour,"date":date,"total":total,
        "congestion":congestion,"avg_speed":avg_speed,
        "pollution_aqi":pollution,
        "vehicle_types":VEHICLE_TYPES,
        "vehicle_counts":counts,
        "vehicle_colors":VEHICLE_COLORS,
        "vehicle_icons":VEHICLE_ICONS,
        "hourly_series":hourly,
        "peak_hour":peak,
        "lat":CITIES[city]["lat"],"lng":CITIES[city]["lng"],
    })

@app.route("/api/vehicle_types")
def api_vehicle_types():
    city = request.args.get("city","Mumbai")
    date = request.args.get("date", datetime.now().strftime("%Y-%m-%d"))
    # Return 7-day trend per vehicle type
    trend = {}
    for i, vt in enumerate(VEHICLE_TYPES):
        daily = []
        for d in range(7):
            day = (datetime.now() - timedelta(days=6-d)).strftime("%Y-%m-%d")
            total, counts = generate_traffic(city, 9, day)
            daily.append(counts[i])
        trend[vt] = daily
    dates = [(datetime.now() - timedelta(days=6-d)).strftime("%b %d") for d in range(7)]
    return jsonify({"city":city,"dates":dates,"trend":trend,
                    "colors":VEHICLE_COLORS,"icons":VEHICLE_ICONS})

@app.route("/api/hourly_trends")
def api_hourly_trends():
    city = request.args.get("city","Mumbai")
    date = request.args.get("date", datetime.now().strftime("%Y-%m-%d"))
    hourly = generate_hourly_series(city, date)
    # also return by vehicle type for each hour
    vtype_hourly = {vt:[] for vt in VEHICLE_TYPES}
    for h in range(24):
        _, counts = generate_traffic(city, h, date)
        for i, vt in enumerate(VEHICLE_TYPES):
            vtype_hourly[vt].append(counts[i])
    return jsonify({
        "city":city,"date":date,
        "total_series":hourly,
        "vehicle_series":vtype_hourly,
        "colors":VEHICLE_COLORS,
        "labels":[f"{h}:00" for h in range(24)],
    })

@app.route("/api/route_check", methods=["POST"])
def api_route_check():
    data   = request.get_json()
    city   = data.get("city","Mumbai")
    origin = data.get("origin","").strip() or "Your Location"
    dest   = data.get("destination","").strip() or "Destination"
    result = generate_route_suggestion(origin, dest, city)
    return jsonify(result)

@app.route("/api/city_map")
def api_city_map():
    cities_data = []
    hour = datetime.now().hour
    for name, info in CITIES.items():
        total, _ = generate_traffic(name, hour)
        hf = hour_factor(hour) * info["mult"]
        status = "High" if hf > 1.2 else "Moderate" if hf > 0.8 else "Low"
        cities_data.append({
            "name":name,"state":info["state"],
            "lat":info["lat"],"lng":info["lng"],
            "total":total,"status":status,
            "color":"#f64f59" if status=="High" else "#F7971E" if status=="Moderate" else "#43e97b",
        })
    return jsonify({"cities":cities_data})

if __name__ == "__main__":
    os.makedirs("data", exist_ok=True)
    app.run(debug=True)
